/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/BUAA/CS/ComputerOrgan/ISE/P4/SingleCycleNew/Controller.v";
static int ng1[] = {0, 0};
static unsigned int ng2[] = {35U, 0U};
static unsigned int ng3[] = {4392U, 0U};
static unsigned int ng4[] = {43U, 0U};
static unsigned int ng5[] = {2336U, 0U};
static unsigned int ng6[] = {0U, 0U};
static unsigned int ng7[] = {8U, 0U};
static unsigned int ng8[] = {257U, 0U};
static unsigned int ng9[] = {33U, 0U};
static unsigned int ng10[] = {280U, 0U};
static unsigned int ng11[] = {792U, 0U};
static unsigned int ng12[] = {36U, 0U};
static unsigned int ng13[] = {24U, 0U};
static unsigned int ng14[] = {37U, 0U};
static unsigned int ng15[] = {152U, 0U};
static unsigned int ng16[] = {42U, 0U};
static unsigned int ng17[] = {920U, 0U};
static unsigned int ng18[] = {4U, 0U};
static unsigned int ng19[] = {1792U, 0U};
static unsigned int ng20[] = {13U, 0U};
static unsigned int ng21[] = {200U, 0U};
static unsigned int ng22[] = {15U, 0U};
static unsigned int ng23[] = {360U, 0U};
static unsigned int ng24[] = {2U, 0U};
static unsigned int ng25[] = {3U, 0U};
static unsigned int ng26[] = {14U, 0U};



static void Initial_36_0(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(36, ng0);

LAB2:    xsi_set_current_line(37, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 1840);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 13, 0LL);

LAB1:    return;
}

static void Cont_39_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    unsigned int t36;
    unsigned int t37;
    char *t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    unsigned int t42;
    unsigned int t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    unsigned int t49;
    unsigned int t50;
    char *t51;
    unsigned int t52;
    unsigned int t53;
    char *t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t61;
    unsigned int t62;
    unsigned int t63;
    char *t64;
    unsigned int t65;
    unsigned int t66;
    char *t67;
    unsigned int t68;
    unsigned int t69;
    char *t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    unsigned int t75;
    unsigned int t76;
    char *t77;
    unsigned int t78;
    unsigned int t79;
    char *t80;
    unsigned int t81;
    unsigned int t82;
    char *t83;
    char *t84;
    char *t85;
    char *t86;
    char *t87;
    unsigned int t88;
    unsigned int t89;
    char *t90;
    unsigned int t91;
    unsigned int t92;
    char *t93;
    unsigned int t94;
    unsigned int t95;
    char *t96;
    char *t97;
    char *t98;
    char *t99;
    char *t100;
    unsigned int t101;
    unsigned int t102;
    char *t103;
    unsigned int t104;
    unsigned int t105;
    char *t106;
    unsigned int t107;
    unsigned int t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    unsigned int t114;
    unsigned int t115;
    char *t116;
    unsigned int t117;
    unsigned int t118;
    char *t119;
    unsigned int t120;
    unsigned int t121;
    char *t122;
    char *t123;
    char *t124;
    char *t125;
    char *t126;
    unsigned int t127;
    unsigned int t128;
    char *t129;
    unsigned int t130;
    unsigned int t131;
    char *t132;
    unsigned int t133;
    unsigned int t134;
    char *t135;

LAB0:    t1 = (t0 + 2508U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(39, ng0);
    t2 = (t0 + 1840);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = (t0 + 3224);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 1U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 0);
    t18 = (t0 + 3188);
    t19 = (t18 + 32U);
    t20 = *((char **)t19);
    t21 = (t20 + 40U);
    t22 = *((char **)t21);
    memset(t22, 0, 8);
    t23 = 2U;
    t24 = t23;
    t25 = (t4 + 4);
    t26 = *((unsigned int *)t4);
    t23 = (t23 & t26);
    t27 = *((unsigned int *)t25);
    t24 = (t24 & t27);
    t23 = (t23 >> 1);
    t24 = (t24 >> 1);
    t28 = (t22 + 4);
    t29 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t29 | t23);
    t30 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t30 | t24);
    xsi_driver_vfirst_trans(t18, 0, 0);
    t31 = (t0 + 3152);
    t32 = (t31 + 32U);
    t33 = *((char **)t32);
    t34 = (t33 + 40U);
    t35 = *((char **)t34);
    memset(t35, 0, 8);
    t36 = 4U;
    t37 = t36;
    t38 = (t4 + 4);
    t39 = *((unsigned int *)t4);
    t36 = (t36 & t39);
    t40 = *((unsigned int *)t38);
    t37 = (t37 & t40);
    t36 = (t36 >> 2);
    t37 = (t37 >> 2);
    t41 = (t35 + 4);
    t42 = *((unsigned int *)t35);
    *((unsigned int *)t35) = (t42 | t36);
    t43 = *((unsigned int *)t41);
    *((unsigned int *)t41) = (t43 | t37);
    xsi_driver_vfirst_trans(t31, 0, 0);
    t44 = (t0 + 3116);
    t45 = (t44 + 32U);
    t46 = *((char **)t45);
    t47 = (t46 + 40U);
    t48 = *((char **)t47);
    memset(t48, 0, 8);
    t49 = 8U;
    t50 = t49;
    t51 = (t4 + 4);
    t52 = *((unsigned int *)t4);
    t49 = (t49 & t52);
    t53 = *((unsigned int *)t51);
    t50 = (t50 & t53);
    t49 = (t49 >> 3);
    t50 = (t50 >> 3);
    t54 = (t48 + 4);
    t55 = *((unsigned int *)t48);
    *((unsigned int *)t48) = (t55 | t49);
    t56 = *((unsigned int *)t54);
    *((unsigned int *)t54) = (t56 | t50);
    xsi_driver_vfirst_trans(t44, 0, 0);
    t57 = (t0 + 3080);
    t58 = (t57 + 32U);
    t59 = *((char **)t58);
    t60 = (t59 + 40U);
    t61 = *((char **)t60);
    memset(t61, 0, 8);
    t62 = 16U;
    t63 = t62;
    t64 = (t4 + 4);
    t65 = *((unsigned int *)t4);
    t62 = (t62 & t65);
    t66 = *((unsigned int *)t64);
    t63 = (t63 & t66);
    t62 = (t62 >> 4);
    t63 = (t63 >> 4);
    t67 = (t61 + 4);
    t68 = *((unsigned int *)t61);
    *((unsigned int *)t61) = (t68 | t62);
    t69 = *((unsigned int *)t67);
    *((unsigned int *)t67) = (t69 | t63);
    xsi_driver_vfirst_trans(t57, 0, 0);
    t70 = (t0 + 3044);
    t71 = (t70 + 32U);
    t72 = *((char **)t71);
    t73 = (t72 + 40U);
    t74 = *((char **)t73);
    memset(t74, 0, 8);
    t75 = 96U;
    t76 = t75;
    t77 = (t4 + 4);
    t78 = *((unsigned int *)t4);
    t75 = (t75 & t78);
    t79 = *((unsigned int *)t77);
    t76 = (t76 & t79);
    t75 = (t75 >> 5);
    t76 = (t76 >> 5);
    t80 = (t74 + 4);
    t81 = *((unsigned int *)t74);
    *((unsigned int *)t74) = (t81 | t75);
    t82 = *((unsigned int *)t80);
    *((unsigned int *)t80) = (t82 | t76);
    xsi_driver_vfirst_trans(t70, 0, 1);
    t83 = (t0 + 3008);
    t84 = (t83 + 32U);
    t85 = *((char **)t84);
    t86 = (t85 + 40U);
    t87 = *((char **)t86);
    memset(t87, 0, 8);
    t88 = 896U;
    t89 = t88;
    t90 = (t4 + 4);
    t91 = *((unsigned int *)t4);
    t88 = (t88 & t91);
    t92 = *((unsigned int *)t90);
    t89 = (t89 & t92);
    t88 = (t88 >> 7);
    t89 = (t89 >> 7);
    t93 = (t87 + 4);
    t94 = *((unsigned int *)t87);
    *((unsigned int *)t87) = (t94 | t88);
    t95 = *((unsigned int *)t93);
    *((unsigned int *)t93) = (t95 | t89);
    xsi_driver_vfirst_trans(t83, 0, 2);
    t96 = (t0 + 2972);
    t97 = (t96 + 32U);
    t98 = *((char **)t97);
    t99 = (t98 + 40U);
    t100 = *((char **)t99);
    memset(t100, 0, 8);
    t101 = 1024U;
    t102 = t101;
    t103 = (t4 + 4);
    t104 = *((unsigned int *)t4);
    t101 = (t101 & t104);
    t105 = *((unsigned int *)t103);
    t102 = (t102 & t105);
    t101 = (t101 >> 10);
    t102 = (t102 >> 10);
    t106 = (t100 + 4);
    t107 = *((unsigned int *)t100);
    *((unsigned int *)t100) = (t107 | t101);
    t108 = *((unsigned int *)t106);
    *((unsigned int *)t106) = (t108 | t102);
    xsi_driver_vfirst_trans(t96, 0, 0);
    t109 = (t0 + 2936);
    t110 = (t109 + 32U);
    t111 = *((char **)t110);
    t112 = (t111 + 40U);
    t113 = *((char **)t112);
    memset(t113, 0, 8);
    t114 = 2048U;
    t115 = t114;
    t116 = (t4 + 4);
    t117 = *((unsigned int *)t4);
    t114 = (t114 & t117);
    t118 = *((unsigned int *)t116);
    t115 = (t115 & t118);
    t114 = (t114 >> 11);
    t115 = (t115 >> 11);
    t119 = (t113 + 4);
    t120 = *((unsigned int *)t113);
    *((unsigned int *)t113) = (t120 | t114);
    t121 = *((unsigned int *)t119);
    *((unsigned int *)t119) = (t121 | t115);
    xsi_driver_vfirst_trans(t109, 0, 0);
    t122 = (t0 + 2900);
    t123 = (t122 + 32U);
    t124 = *((char **)t123);
    t125 = (t124 + 40U);
    t126 = *((char **)t125);
    memset(t126, 0, 8);
    t127 = 4096U;
    t128 = t127;
    t129 = (t4 + 4);
    t130 = *((unsigned int *)t4);
    t127 = (t127 & t130);
    t131 = *((unsigned int *)t129);
    t128 = (t128 & t131);
    t127 = (t127 >> 12);
    t128 = (t128 >> 12);
    t132 = (t126 + 4);
    t133 = *((unsigned int *)t126);
    *((unsigned int *)t126) = (t133 | t127);
    t134 = *((unsigned int *)t132);
    *((unsigned int *)t132) = (t134 | t128);
    xsi_driver_vfirst_trans(t122, 0, 0);
    t135 = (t0 + 2848);
    *((int *)t135) = 1;

LAB1:    return;
}

static void Always_40_2(char *t0)
{
    char t9[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    char *t7;
    char *t8;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;

LAB0:    t1 = (t0 + 2652U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(40, ng0);
    t2 = (t0 + 2856);
    *((int *)t2) = 1;
    t3 = (t0 + 2680);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(40, ng0);

LAB5:    xsi_set_current_line(41, ng0);
    t4 = (t0 + 600U);
    t5 = *((char **)t4);

LAB6:    t4 = ((char*)((ng2)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t4, 6);
    if (t6 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng4)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng6)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng18)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng20)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng22)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB17;

LAB18:    t2 = ((char*)((ng24)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng25)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB21;

LAB22:
LAB23:    goto LAB2;

LAB7:    xsi_set_current_line(42, ng0);

LAB24:    xsi_set_current_line(43, ng0);
    t7 = ((char*)((ng3)));
    t8 = (t0 + 1840);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 13, 0LL);
    goto LAB23;

LAB9:    xsi_set_current_line(45, ng0);

LAB25:    xsi_set_current_line(46, ng0);
    t3 = ((char*)((ng5)));
    t4 = (t0 + 1840);
    xsi_vlogvar_wait_assign_value(t4, t3, 0, 0, 13, 0LL);
    goto LAB23;

LAB11:    xsi_set_current_line(48, ng0);

LAB26:    xsi_set_current_line(49, ng0);
    t3 = (t0 + 692U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng7)));
    memset(t9, 0, 8);
    t7 = (t4 + 4);
    t8 = (t3 + 4);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t3);
    t12 = (t10 ^ t11);
    t13 = *((unsigned int *)t7);
    t14 = *((unsigned int *)t8);
    t15 = (t13 ^ t14);
    t16 = (t12 | t15);
    t17 = *((unsigned int *)t7);
    t18 = *((unsigned int *)t8);
    t19 = (t17 | t18);
    t20 = (~(t19));
    t21 = (t16 & t20);
    if (t21 != 0)
        goto LAB30;

LAB27:    if (t19 != 0)
        goto LAB29;

LAB28:    *((unsigned int *)t9) = 1;

LAB30:    t23 = (t9 + 4);
    t24 = *((unsigned int *)t23);
    t25 = (~(t24));
    t26 = *((unsigned int *)t9);
    t27 = (t26 & t25);
    t28 = (t27 != 0);
    if (t28 > 0)
        goto LAB31;

LAB32:    xsi_set_current_line(52, ng0);

LAB35:    xsi_set_current_line(53, ng0);
    t2 = (t0 + 692U);
    t3 = *((char **)t2);

LAB36:    t2 = ((char*)((ng9)));
    t6 = xsi_vlog_unsigned_case_compare(t3, 6, t2, 6);
    if (t6 == 1)
        goto LAB37;

LAB38:    t2 = ((char*)((ng2)));
    t6 = xsi_vlog_unsigned_case_compare(t3, 6, t2, 6);
    if (t6 == 1)
        goto LAB39;

LAB40:    t2 = ((char*)((ng12)));
    t6 = xsi_vlog_unsigned_case_compare(t3, 6, t2, 6);
    if (t6 == 1)
        goto LAB41;

LAB42:    t2 = ((char*)((ng14)));
    t6 = xsi_vlog_unsigned_case_compare(t3, 6, t2, 6);
    if (t6 == 1)
        goto LAB43;

LAB44:    t2 = ((char*)((ng16)));
    t6 = xsi_vlog_unsigned_case_compare(t3, 6, t2, 6);
    if (t6 == 1)
        goto LAB45;

LAB46:    t2 = ((char*)((ng6)));
    t6 = xsi_vlog_unsigned_case_compare(t3, 6, t2, 6);
    if (t6 == 1)
        goto LAB47;

LAB48:
LAB49:
LAB33:    goto LAB23;

LAB13:    xsi_set_current_line(75, ng0);

LAB56:    xsi_set_current_line(76, ng0);
    t4 = ((char*)((ng19)));
    t7 = (t0 + 1840);
    xsi_vlogvar_wait_assign_value(t7, t4, 0, 0, 13, 0LL);
    goto LAB23;

LAB15:    xsi_set_current_line(78, ng0);

LAB57:    xsi_set_current_line(79, ng0);
    t4 = ((char*)((ng21)));
    t7 = (t0 + 1840);
    xsi_vlogvar_wait_assign_value(t7, t4, 0, 0, 13, 0LL);
    goto LAB23;

LAB17:    xsi_set_current_line(81, ng0);

LAB58:    xsi_set_current_line(82, ng0);
    t4 = ((char*)((ng23)));
    t7 = (t0 + 1840);
    xsi_vlogvar_wait_assign_value(t7, t4, 0, 0, 13, 0LL);
    goto LAB23;

LAB19:    xsi_set_current_line(84, ng0);

LAB59:    xsi_set_current_line(85, ng0);
    t4 = ((char*)((ng18)));
    t7 = (t0 + 1840);
    xsi_vlogvar_wait_assign_value(t7, t4, 0, 0, 13, 0LL);
    goto LAB23;

LAB21:    xsi_set_current_line(87, ng0);

LAB60:    xsi_set_current_line(88, ng0);
    t4 = ((char*)((ng26)));
    t7 = (t0 + 1840);
    xsi_vlogvar_wait_assign_value(t7, t4, 0, 0, 13, 0LL);
    goto LAB23;

LAB29:    t22 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t22) = 1;
    goto LAB30;

LAB31:    xsi_set_current_line(49, ng0);

LAB34:    xsi_set_current_line(50, ng0);
    t29 = ((char*)((ng8)));
    t30 = (t0 + 1840);
    xsi_vlogvar_wait_assign_value(t30, t29, 0, 0, 13, 0LL);
    goto LAB33;

LAB37:    xsi_set_current_line(54, ng0);

LAB50:    xsi_set_current_line(55, ng0);
    t4 = ((char*)((ng10)));
    t7 = (t0 + 1840);
    xsi_vlogvar_wait_assign_value(t7, t4, 0, 0, 13, 0LL);
    goto LAB49;

LAB39:    xsi_set_current_line(57, ng0);

LAB51:    xsi_set_current_line(58, ng0);
    t4 = ((char*)((ng11)));
    t7 = (t0 + 1840);
    xsi_vlogvar_wait_assign_value(t7, t4, 0, 0, 13, 0LL);
    goto LAB49;

LAB41:    xsi_set_current_line(60, ng0);

LAB52:    xsi_set_current_line(61, ng0);
    t4 = ((char*)((ng13)));
    t7 = (t0 + 1840);
    xsi_vlogvar_wait_assign_value(t7, t4, 0, 0, 13, 0LL);
    goto LAB49;

LAB43:    xsi_set_current_line(63, ng0);

LAB53:    xsi_set_current_line(64, ng0);
    t4 = ((char*)((ng15)));
    t7 = (t0 + 1840);
    xsi_vlogvar_wait_assign_value(t7, t4, 0, 0, 13, 0LL);
    goto LAB49;

LAB45:    xsi_set_current_line(66, ng0);

LAB54:    xsi_set_current_line(67, ng0);
    t4 = ((char*)((ng17)));
    t7 = (t0 + 1840);
    xsi_vlogvar_wait_assign_value(t7, t4, 0, 0, 13, 0LL);
    goto LAB49;

LAB47:    xsi_set_current_line(69, ng0);

LAB55:    xsi_set_current_line(70, ng0);
    t4 = ((char*)((ng6)));
    t7 = (t0 + 1840);
    xsi_vlogvar_wait_assign_value(t7, t4, 0, 0, 13, 0LL);
    goto LAB49;

}


extern void work_m_00000000000614441193_4144471541_init()
{
	static char *pe[] = {(void *)Initial_36_0,(void *)Cont_39_1,(void *)Always_40_2};
	xsi_register_didat("work_m_00000000000614441193_4144471541", "isim/MIPS_CODE_isim_beh.exe.sim/work/m_00000000000614441193_4144471541.didat");
	xsi_register_executes(pe);
}
