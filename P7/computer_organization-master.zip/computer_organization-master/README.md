# computer_organization
BUAA computer organization source code for project 1 ~8 \
P0: logisim basic operations \
P1: verilog syntax\
P2: MIPS Assembly language \
P3: monocycle CPU designed by logisim \
P4: monocycle CPU designed by ISE \
P5: pipeline CPU supporting 10 instructions designed by ISE \
P6: pipeline CPU supporting 50 instructions desinged by ISE \
P7: pipeline CPU supporting 50 instructions and exception/interruption desinged by ISE  \
P8: pipeline CPU supporting 50 instructions, exception/interruption and devices running on FPGA  \
    devices including 8-SEG LED, timer, UART, key, etc.
